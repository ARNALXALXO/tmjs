  import * as THREE from '/three.module.js';
  import { OrbitControls } from '/jsm/OrbitControls.js';
  
  import { OBJLoader } from '/Objloader /OBJLoader.js';
  const renderer = new THREE.WebGLRenderer();
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);

  const scene = new THREE.Scene();

  const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 1, 10000);
  //=========light ========
  renderer.setClearColor(0x0000ff); 
  var light = new THREE.AmbientLight(0xffffff, 0.5);
  scene.add(light);
  
  //Point light => shading the front face 
  var light1 = new THREE.PointLight(0xffffff, 0.5);
  scene.add(light1);
  
  //=========== object =============
  
  const texture = new THREE.TextureLoader('/img/img.jpg');
  
  // immediately use the texture for material creation
  const material = new THREE.MeshBasicMaterial({ map: texture });
//==call function ===
const loader = new THREE.TextureLoader();

// load a resource
loader.load(
  // resource URL
  '/img/img.jpg',
  function(texture) {
    var geometry = new THREE.BoxGeometry(200, 200, 200);
    var material = new THREE.MeshBasicMaterial({
      map: texture
    });
    var mesh = new THREE.Mesh(geometry, material);
    mesh.position.set(0, 0, -50);
    
    scene.add(mesh);
  }
);







const tex = new THREE.TextureLoader('/img/img.jpg');

// immediately use the texture for material creation
const materialc = new THREE.MeshBasicMaterial({ map: tex });
//==call function ===
const loade = new THREE.TextureLoader();

// load a resource
loade.load(
  // resource URL
  '/img/img.jpg',
  function(tex) {
    var geometry = new THREE.BoxGeometry(200, 200, 200);
    var materialc = new THREE.MeshBasicMaterial({
      map: tex
    });
    var mesh1 = new THREE.Mesh(geometry, materialc);
    mesh1.position.set(0, 0, -300);

    scene.add(mesh1);
  }
);
//======================
  const controls = new OrbitControls(camera, renderer.domElement);

//================================
  camera.position.set(0, 20, 200);
  //controls.autoRotate = true;
  controls.update();

  function animate() {
    requestAnimationFrame(animate);
    
   controls.autoRotate = true;

   controls.update();
    renderer.render(scene, camera);

  }
  animate();

