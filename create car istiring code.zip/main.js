// drow this dot commands
window.addEventListener('touchstart',function(e){
  console.log('start');
  [...e.changedTouches].forEach(touch =>{
dot = document.createElement("div");
dot.classList.add("dot");   
dot.style.top = `${touch.pageY}px`
dot.style.left = `${touch.pageX}px`
dot.id = touch.identifier 
document.getElementById('top-help').append(dot);
   
  });
});


// dot is move commands
window.addEventListener('touchmove', function(e) {
  console.log('move');
  //alert('pass');
[...e.changedTouches].forEach(touch =>{
const dot = document.getElementById(touch.identifier); 
dot.style.top = `${touch.pageY}px`
dot.style.left = `${touch.pageX}px`  
  });
});



// removed this dot commands
window.addEventListener('touchend', function(e) {
  console.log('end');
  [...e.changedTouches].forEach(touch =>{
  const dot = document.getElementById(touch.identifier); 
   dot.remove(); 
  });
});