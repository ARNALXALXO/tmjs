import * as THREE from '/js/three.module.js';
import { OrbitControls } from '/js/OrbitControls.js';
import Stats from '/js/stats.module.js';

const scene = new THREE.Scene()

const camera = new THREE.PerspectiveCamera(
    75,
    window.innerWidth / window.innerHeight,
    0.1,
    1000
)
camera.position.z = 2

const renderer = new THREE.WebGLRenderer()
renderer.setSize(window.innerWidth, window.innerHeight)
document.body.appendChild(renderer.domElement)

const controls = new OrbitControls(camera, renderer.domElement)
//controls.addEventListener('change', render)

const geometry = new THREE.BoxGeometry(50,50,50);
const material = new THREE.MeshBasicMaterial({
    color: 0xffff
});

const cube = new THREE.Mesh(geometry, material);
cube.position.set(0, 0, -80); 
scene.add(cube);

//==================================
// stats module kya hai ak timer hai kyoki vah time ki trha kam karta hai
const stats = Stats()
document.body.appendChild(stats.dom)
//==================================
function animate() {
    requestAnimationFrame(animate)

    cube.rotation.x += 0.01
    cube.rotation.y += 0.01

    //render()

    stats.update()
    renderer.render(scene, camera)
}

animate()

